const mysql = require('mysql2');

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'aulanodejs'

})

function connect(){
    connection.connect((error)=>{
        if(error){
            console.error('Não foi possivel conectar ao banco de dados! Erro:',error.stack)
            return 
        }else{
            console.log("Banco de Dados conectado com sucesso!")
        }   
    })

}

function disconnect(){
    connection.end((error)=>{
        if (error){
            console.error('Erro ao se disconectar', error.stack);
        }else{
            console.log("Desconectado com sucesso!")
        }
    })
}

async function consultUser(){
    try {
        const [result] = await connection.promise().query('SELECT * FROM users');
        return result; // Retorna o resultado diretamente
      
    } catch (error) {
        console.error("Erro ao consultar sua tabela", error.stack);
        throw error; // Lança o erro para ser tratado externamente
     }
}

async function insertUser(nome,cpf,idade,endereco){
    try {
        await connection.promise().query(`INSERT INTO users(CPF,nome,idade,endereco) VALUES('${cpf}','${nome}',${idade},'${endereco}');`)
        return true;
    } catch (error) {
        console.error("Não foi possivel cadastrar o usuario:",error.stack)
        return false
    }
}

async function buscarUsuarioPCPF(cpf){
    try {
        const [result] = await connection.promise().query(`SELECT * FROM users WHERE CPF = '${cpf}'`)
        return result
    } catch (error) {
        console.error("Não foi possivel consultar o usuario:",error.stack)
        return false
    }

}
async function buscarUsuarioPName(nome){
    try {
        const [result] = await connection.promise().query(`SELECT * FROM users WHERE nome = '${nome}'`)
        return result
    } catch (error) {
        console.error("Não foi possivel consultar o usuario:",error.stack)
        return false
    }

}



module.exports = {connect,disconnect,consultUser,insertUser, buscarUsuarioPCPF,buscarUsuarioPName}