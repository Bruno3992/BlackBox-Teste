var express = require('express');
var router = express.Router();

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});


router.get('/login', function(req, res, next) {
  res.render('loginusuario',{result:result})
});

router.post('/consultuser', function(req,res){
  let {cpfUser,nameUser} = req.body
  if (cpfUser != '') {
    mysql.buscarUsuarioPCPF(cpfUser)
    .then((result) => {
      if (result.length>0) {
        
        res.render('alterarUsuario',{result:result})
      }else{
        res.send("Nenhum Usuario Encontrado")
      }     
    })
    .catch((error) => {
      console.error('Erro na consulta:', error);
      res.send("Ocorreu um erro no processamento dos dados!")
    });
  }else{
   
      mysql.buscarUsuarioPName(nameUser)
      .then((result) => {
        if (result.length>0) {
          res.render('alterarUsuario',{result:result})
        }else{
          res.send("Nenhum Usuario Encontrado")
        }     
      })
      .catch((error) => {
        console.error('Erro na consulta:', error);
        res.send("Ocorreu um erro no processamento dos dados!")
      });
  }

})

module.exports = router;
