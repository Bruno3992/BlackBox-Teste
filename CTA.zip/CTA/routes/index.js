var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'CEEP' });
});






module.exports = router;



// GET - SOLICITAR 1 REQUISIÇÃO - EXPOSTA NA URL
//POST - VARIAS SOLICITAÇÕES - OCULTA NO CORPO DA MENSAGEM
//DELETE - DELETAR ALGUMA INFORMAÇÃO
//PUT - ATUALIZAR ALGUMA INFORMAÇÃO